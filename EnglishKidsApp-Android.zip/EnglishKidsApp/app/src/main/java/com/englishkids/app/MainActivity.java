package com.englishkids.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.WindowManager;
import java.util.Locale;

public class MainActivity extends Activity {

    private WebView webView;
    private TextToSpeech ttsVi;
    private TextToSpeech ttsEn;
    private boolean ttsViReady = false;
    private boolean ttsEnReady = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    class AndroidTTSBridge {

        // Giọng Việt — gốc máy, dùng cho MẸ HỎI
        @JavascriptInterface
        public void speakVi(String text, float rate, float pitch) {
            if (!ttsViReady || text == null || text.isEmpty()) return;
            ttsVi.setSpeechRate(Math.max(0.4f, Math.min(1.5f, rate)));
            ttsVi.setPitch(Math.max(0.5f, Math.min(2.0f, pitch)));
            ttsVi.speak(text, TextToSpeech.QUEUE_FLUSH, null, "vi_" + System.currentTimeMillis());
        }

        // Giọng Anh — gốc máy (backup khi cloud fail), dùng cho BÉ ĐÁP
        @JavascriptInterface
        public void speakEn(String text, String langCode, float rate, float pitch) {
            if (!ttsEnReady || text == null || text.isEmpty()) return;
            Locale locale;
            switch (langCode) {
                case "en-GB": locale = Locale.UK; break;
                case "en-AU": locale = new Locale("en", "AU"); break;
                case "en-IN": locale = new Locale("en", "IN"); break;
                default:      locale = Locale.US; break;
            }
            ttsEn.setLanguage(locale);
            ttsEn.setSpeechRate(Math.max(0.4f, Math.min(2.0f, rate)));
            ttsEn.setPitch(Math.max(0.5f, Math.min(2.0f, pitch)));
            ttsEn.speak(text, TextToSpeech.QUEUE_FLUSH, null, "en_" + System.currentTimeMillis());
        }

        @JavascriptInterface
        public void stop() {
            if (ttsViReady) ttsVi.stop();
            if (ttsEnReady) ttsEn.stop();
        }

        @JavascriptInterface
        public boolean isViReady() { return ttsViReady; }

        @JavascriptInterface
        public boolean isEnReady() { return ttsEnReady; }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        // KEY: cho phép file:// gọi HTTPS API — bỏ CORS restriction
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setDomStorageEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);

        webView.addJavascriptInterface(new AndroidTTSBridge(), "AndroidTTS");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String url = r.getUrl().toString();
                // Giữ http/file trong WebView
                if (url.startsWith("http") || url.startsWith("file")) {
                    v.loadUrl(url); return true;
                }
                return false;
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                // Báo HTML biết TTS đã sẵn sàng
                v.evaluateJavascript(
                    "if(typeof onAndroidTTSReady==='function')" +
                    "onAndroidTTSReady(" + ttsViReady + "," + ttsEnReady + ");", null);
            }
        });

        webView.loadUrl("file:///android_asset/index.html");

        // Init TTS Tiếng Việt
        ttsVi = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = ttsVi.setLanguage(new Locale("vi", "VN"));
                ttsViReady = (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED);
                notifyReady();
            }
        });

        // Init TTS Tiếng Anh
        ttsEn = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsEn.setLanguage(Locale.US);
                ttsEnReady = true;
                notifyReady();
            }
        });
    }

    private void notifyReady() {
        handler.post(() -> {
            if (webView != null)
                webView.evaluateJavascript(
                    "if(typeof onAndroidTTSReady==='function')" +
                    "onAndroidTTSReady(" + ttsViReady + "," + ttsEnReady + ");", null);
        });
    }

    @Override protected void onPause()   { super.onPause();   if(ttsViReady) ttsVi.stop(); if(ttsEnReady) ttsEn.stop(); webView.onPause(); }
    @Override protected void onResume()  { super.onResume();  webView.onResume(); }
    @Override protected void onDestroy() {
        super.onDestroy();
        if(ttsVi != null) ttsVi.shutdown();
        if(ttsEn != null) ttsEn.shutdown();
        if(webView != null) { webView.stopLoading(); webView.destroy(); }
    }
    @Override public void onBackPressed() {
        if(webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}

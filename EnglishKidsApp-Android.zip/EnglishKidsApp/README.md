# 📱 Mẹ Dạy Bé Tiếng Anh — Android App

## Cấu trúc project
```
EnglishKidsApp/
├── app/src/main/
│   ├── java/com/englishkids/app/MainActivity.java  ← Code app chính
│   ├── assets/index.html                           ← File HTML (copy vào đây)
│   ├── AndroidManifest.xml
│   └── res/values/themes.xml
├── build.gradle
└── settings.gradle
```

## Cách build APK (2 cách)

### Cách 1: Android Studio (dễ nhất)
1. Tải Android Studio: https://developer.android.com/studio
2. Mở Android Studio → Open → chọn thư mục `EnglishKidsApp`
3. Chờ Gradle sync xong (~2-5 phút lần đầu)
4. Build → Generate Signed Bundle/APK → APK
5. Hoặc nhấn ▶ để chạy thẳng trên máy thật/giả lập

### Cách 2: Build online (không cần cài gì)
1. Tạo tài khoản GitHub (miễn phí)
2. Upload thư mục EnglishKidsApp lên GitHub
3. Dùng GitHub Actions để build APK tự động
4. Tải APK từ tab Actions

## Tại sao App tốt hơn Web?
| Tính năng | Web | App Android |
|-----------|-----|-------------|
| Giọng tiếng Việt | ❌ Phụ thuộc mạng | ✅ Gốc máy, không cần mạng |
| Giọng tiếng Anh | ⚠️ Hay bị chặn | ✅ Gốc máy, luôn hoạt động |
| Tốc độ phát âm | Chậm (network) | Nhanh (local) |
| Hoạt động offline | Không | Có (sau lần đầu) |
| Cài đặt | Không cần | Nhấp APK → Cài |

## Lưu ý
- Máy cần có **Google Text-to-Speech** (thường có sẵn)
- Nếu thiếu giọng tiếng Việt: Cài đặt → Quản lý chung → Ngôn ngữ → 
  Chuyển văn bản thành giọng nói → Tải tiếng Việt
- APK debug có thể cài thẳng (bật "Cài từ nguồn không xác định")
